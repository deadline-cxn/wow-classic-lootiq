local ADDON_NAME, ns = ...

local function AddSection(tooltip, title, store, kills)
    local items = ns.SortedDrops(store)

    tooltip:AddLine(" ")
    tooltip:AddLine(title, 0.5, 0.8, 1)
    for i = 1, #items do
        local d = items[i]
        local pct = kills > 0 and (d.occurrences / kills * 100) or 0
        tooltip:AddLine(("  %s x%d  (%.0f%%)"):format(d.link, d.count, pct))
    end
end

-- Sums (price x count) across every known drop and skin, plus any coin
-- looted directly (entry.money, accumulated in Loot.lua), giving the
-- expected gold value of a single kill. Items with no known price (no AH
-- scan data and no Auctionator) contribute nothing, so this is a lower
-- bound rather than a true average when pricing is incomplete. Shared with
-- the Source Database panel (CreatureDatabase.lua).
function ns.GetAverageValuePerKill(entry)
    if entry.kills <= 0 then return nil end

    local total = entry.money or 0
    for _, drop in pairs(entry.drops) do
        local price = ns.GetItemPrice(drop.link)
        if price then total = total + price * drop.count end
    end
    for _, skin in pairs(entry.skins) do
        local price = ns.GetItemPrice(skin.link)
        if price then total = total + price * skin.count end
    end

    return total / entry.kills
end

-- Exposed (not local) so BrowserPanel.lua can show this same content on a
-- hover tooltip for a creature/vendor that isn't a live unit at all (a
-- Source Database list row, or the model preview shared with the Item
-- Database) - there's no UnitGUID to hook OnTooltipSetUnit with there, so
-- those callers build the tooltip's header line themselves (the name
-- Blizzard would normally add first for a live unit) and then call this to
-- append the same kills/drops/skins/value lines used everywhere else.
function ns.AddDropLines(tooltip, creatureID)
    local entry = ns.accountDB.creatures[creatureID]
    -- entry.kills is tracked for every PARTY_KILL regardless of whether
    -- anything was ever looted from it (see Loot.lua's RecordKill), so this
    -- shows the kill count for any tracked kill - not just ones that also
    -- happened to drop something, which this used to require before even
    -- printing the count (a creature with 0 known drops/skins got no
    -- tooltip line at all, even though its kill count was accurate).
    if not entry or entry.kills <= 0 then return end

    tooltip:AddLine(" ")
    tooltip:AddLine(("LootIQ - %d kills tracked:"):format(entry.kills), 0.5, 0.8, 1)

    if next(entry.drops) ~= nil then
        AddSection(tooltip, "Known drops:", entry.drops, entry.kills)
    end
    if next(entry.skins) ~= nil then
        AddSection(tooltip, "Skinning:", entry.skins, entry.kills)
    end

    local avgValue = ns.GetAverageValuePerKill(entry)
    if avgValue and avgValue > 0 then
        tooltip:AddLine(" ")
        tooltip:AddLine(("Average value per kill: %s"):format(ns.FormatPrice(math.floor(avgValue))), 0.5, 0.8, 1)
    end

    tooltip:Show()
end

local MAX_SOURCE_LINES = 12

-- Two per line ("Name (X%), Name (Y%)"), highest drop rate first, capped
-- to the top MAX_SOURCE_LINES overall so an item with many known sources
-- doesn't take over the tooltip.
local function AddSourceLine(tooltip, key)
    local sources = ns.GetRankedItemSources(key)
    if not sources then return end

    tooltip:AddLine(" ")
    tooltip:AddLine("LootIQ sources:", 0.5, 0.8, 1)

    local shown = math.min(#sources, MAX_SOURCE_LINES)
    for i = 1, shown, 2 do
        local first = ("%s (%.0f%%)"):format(sources[i].name, sources[i].pct)
        local second = sources[i + 1]
        local line = second and ("%s, %s (%.0f%%)"):format(first, second.name, second.pct) or first
        tooltip:AddLine("  " .. line)
    end
    tooltip:Show()
end

-- Added synchronously, NOT deferred via C_Timer like the unit-tooltip hook
-- below. Both OnTooltipSetItem and TooltipDataProcessor's post-call refire
-- every frame for a bag/vendor item's tooltip (to keep stack counts/
-- charges current), clearing and rebuilding the base tooltip each time. A
-- deferred (next-frame) add here used to land one frame behind that
-- per-frame rebuild, so the tooltip visibly resized smaller-then-bigger on
-- every single frame - that oscillation was the reported flicker. Adding
-- in the same frame as the rebuild avoids that; a plain link/world
-- tooltip only fires this once anyway, so there's no clipping race to
-- defer around here.
local function OnItemTooltip(tooltip)
    if not ns.accountDB then return end

    local _, link = tooltip:GetItem()
    -- ns.GetItemKey (not a bare itemID) so a random-suffix item looks up
    -- its own specific roll's entry rather than whichever roll happened to
    -- be recorded under the bare itemID (see Core.lua's ns.GetItemKey).
    local key = link and ns.GetItemKey(link)
    if not key then return end

    AddSourceLine(tooltip, key)
end

-- Retail (Midnight) can populate an item tooltip asynchronously in a way
-- OnTooltipSetItem doesn't reliably fire for - TooltipDataProcessor is the
-- modern replacement, confirmed via Auctionator's own Source/Tooltips/
-- Hooks.lua, which branches on exactly this (TooltipDataProcessor and
-- C_TooltipInfo both present) and falls back to OnTooltipSetItem only when
-- they're absent. This addon's client is retail-only, so the fallback
-- branch below is dead code here, but kept for parity with that evidence
-- rather than assumed away.
if TooltipDataProcessor and C_TooltipInfo then
    TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tooltip)
        if tooltip == GameTooltip then OnItemTooltip(tooltip) end
    end)
else
    GameTooltip:HookScript("OnTooltipSetItem", OnItemTooltip)
end

-- The "World Cursor" tooltip (hovering a unit directly in the 3D world,
-- rather than a frame like a nameplate/unitframe - the common case while
-- checking out/fighting a creature) hands tooltip:GetUnit() an opaque
-- secret token for that specific internal handle - confirmed NOT fixable
-- by retrying a frame later. Tried reading "mouseover" directly instead
-- (the ordinary, always-public unit ID set by hovering any unit) - user
-- confirmed that ALSO shows nothing, even while the hovered creature was
-- also their actual target, so "mouseover" itself appears to be withheld
-- for identity reads on this client too, not just the tooltip's own
-- internal token.
--
-- "target" is the one unit token this addon has confirmed DOES work for
-- identity (Loot.lua's CacheDeadTarget reads it successfully, with an
-- occasional secret-value retry) - so when the hovered unit IS the
-- player's current target, prefer reading "target" instead of
-- "mouseover". UnitIsUnit never reveals raw identity (just whether two
-- tokens refer to the same unit), so it's safe to use for this check even
-- when "mouseover" itself can't be read as a GUID. This only helps while
-- hovering your own current target, not an arbitrary un-targeted
-- creature - there may be no way to read identity off a merely-hovered,
-- non-targeted unit on this client at all; "mouseover" still gets tried
-- as a fallback in case that's wrong.
local function IsHoveringOwnTarget()
    if not (UnitExists("mouseover") and UnitExists("target")) then return false end
    local same = UnitIsUnit("mouseover", "target")
    if issecretvalue and issecretvalue(same) then return false end
    return same
end

local function ResolveUnitDrop()
    local unit = IsHoveringOwnTarget() and "target" or "mouseover"
    local guid = UnitGUID(unit)
    if not guid then return nil, nil, false end
    if issecretvalue and issecretvalue(guid) then return nil, nil, true end
    local unitType, _, _, _, _, creatureID = strsplit("-", guid)
    if unitType ~= "Creature" and unitType ~= "Vehicle" then return nil, nil, false end
    return guid, tonumber(creatureID), false
end

local function OnUnitTooltip(tooltip)
    if not ns.accountDB then return end

    -- TEMPORARY diagnostic (remove once the hover-tooltip issue is
    -- actually pinned down) - prints exactly what ResolveUnitDrop saw,
    -- since guessing blind through more deploy/retest cycles isn't
    -- converging. Safe to print unconditionally: tostring(guid)/
    -- tostring(creatureID) are nil whenever `secret` is true (ResolveUnitDrop
    -- never returns a secret value itself, only nil in that case).
    local guid, creatureID, secret = ResolveUnitDrop()
    ns.DebugPrint("tooltip debug: mouseoverExists=%s targetExists=%s hoveringOwnTarget=%s guid=%s creatureID=%s secret=%s",
        tostring(UnitExists("mouseover")), tostring(UnitExists("target")), tostring(IsHoveringOwnTarget()),
        tostring(guid), tostring(creatureID), tostring(secret))

    if secret then
        C_Timer.After(0, function()
            if not tooltip:IsShown() then
                ns.DebugPrint("tooltip debug (retry): tooltip no longer shown, bailing")
                return
            end
            local _, retryCreatureID, retrySecret = ResolveUnitDrop()
            ns.DebugPrint("tooltip debug (retry): creatureID=%s secret=%s", tostring(retryCreatureID), tostring(retrySecret))
            if retrySecret or not retryCreatureID then return end
            local entry = ns.accountDB.creatures[retryCreatureID]
            ns.DebugPrint("tooltip debug (retry): entry=%s kills=%s", tostring(entry ~= nil), tostring(entry and entry.kills))
            ns.AddDropLines(tooltip, retryCreatureID)
        end)
        return
    end
    if not creatureID then return end

    do
        local entry = ns.accountDB.creatures[creatureID]
        ns.DebugPrint("tooltip debug (non-secret path): entry=%s kills=%s", tostring(entry ~= nil), tostring(entry and entry.kills))
    end

    -- Deferred to the next frame tick so this runs after other tooltip
    -- addons (e.g. TipTac) finish their own OnTooltipSetUnit pass and
    -- resize the tooltip. Adding lines synchronously here can get them
    -- clipped if something else recalculates the tooltip's size right
    -- after this fires, since that resize happens after ours.
    C_Timer.After(0, function()
        if not tooltip:IsShown() then return end
        local currentGuid, _, currentSecret = ResolveUnitDrop()
        if currentSecret or currentGuid ~= guid then return end
        ns.AddDropLines(tooltip, creatureID)
    end)
end

-- Same TooltipDataProcessor requirement as the item hook above - retail
-- removed the "OnTooltipSetUnit" virtual script from GameTooltip entirely
-- (HookScript on it now errors: "bad argument #2 to HookScript", confirmed
-- in-game on this client), not just made it unreliable. Prat-3.0's own
-- AltNames.lua module hits this exact fork (TooltipDataProcessor present ->
-- Enum.TooltipDataType.Unit; absent -> the old HookScript, which it only
-- uses via SecureHookScript on non-retail).
if TooltipDataProcessor and C_TooltipInfo then
    TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, function(tooltip)
        if tooltip == GameTooltip then OnUnitTooltip(tooltip) end
    end)
else
    GameTooltip:HookScript("OnTooltipSetUnit", OnUnitTooltip)
end

local function AddGatherLines(tooltip, headerFormat, dbKey, storeField, getTotal, zone)
    local entry = ns.accountDB[dbKey][zone]
    if not entry or not next(entry[storeField]) then return end

    local total = getTotal(zone)
    local items = ns.SortedDrops(entry[storeField])
    tooltip:AddLine(" ")
    tooltip:AddLine(headerFormat:format(total, zone), 0.5, 0.8, 1)
    for i = 1, #items do
        local d = items[i]
        local pct = total > 0 and (d.occurrences / total * 100) or 0
        tooltip:AddLine(("  %s x%d  (%.0f%%)"):format(d.link, d.count, pct))
    end
    tooltip:Show()
end

-- There's no dedicated event for "this tooltip is the player's bobber/
-- mining node/herb node" (each is a world object, not a unit or an item),
-- so this infers it the same way for all three: getZone() (from
-- Fishing.lua/Mining.lua/Herbalism.lua) is only non-nil for a while after
-- casting the matching gathering skill, and such a tooltip carries no
-- unit, item, or spell data - just a plain object name. A false positive
-- here (mousing over some other plain-named object while that fallback
-- window happens to still be open) just shows an extra, harmless list, so
-- this doesn't try to be any more precise than that.
local function RegisterGatherTooltip(getZone, dbKey, storeField, getTotal, headerFormat)
    GameTooltip:HookScript("OnShow", function(tooltip)
        if not ns.accountDB then return end
        local zone = getZone()
        if not zone then return end
        if tooltip:GetUnit() or tooltip:GetItem() or tooltip:GetSpell() then return end

        -- Deferred for the same reason as the hooks above - runs after
        -- other tooltip addons finish resizing so these lines don't get
        -- clipped.
        C_Timer.After(0, function()
            if not tooltip:IsShown() then return end
            if tooltip:GetUnit() or tooltip:GetItem() or tooltip:GetSpell() then return end
            AddGatherLines(tooltip, headerFormat, dbKey, storeField, getTotal, zone)
        end)
    end)
end

RegisterGatherTooltip(ns.GetFishingZone, "fishing", "fish", ns.GetTotalFishingCatches,
    "Known catches (LootIQ) - %d caught in %s:")
RegisterGatherTooltip(ns.GetMiningZone, "mining", "ore", ns.GetTotalMiningHarvests,
    "Known harvests (LootIQ) - %d harvested in %s:")
RegisterGatherTooltip(ns.GetHerbalismZone, "herbalism", "herbs", ns.GetTotalHerbalismHarvests,
    "Known harvests (LootIQ) - %d harvested in %s:")
